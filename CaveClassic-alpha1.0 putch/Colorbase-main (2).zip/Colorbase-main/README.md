# Colorbase
 This is the color base. This color base was developed for Pygame and others. The project was created to simplify development. Perhaps I will refine the base of colors
